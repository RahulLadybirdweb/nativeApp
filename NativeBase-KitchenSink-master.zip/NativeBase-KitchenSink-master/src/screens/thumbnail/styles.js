export default {
  container: {
    backgroundColor: "#FFF"
  },
  mb10: {
    marginBottom: 10
  },
  mb35: {
    marginBottom: 35
  }
};
